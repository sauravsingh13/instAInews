import React from "react";
const NewsDetails = () => <div>News Details Page</div>;
export default NewsDetails;
