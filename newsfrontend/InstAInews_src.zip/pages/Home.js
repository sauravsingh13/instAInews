import React from "react";
const Home = () => <div>Welcome to InstAInews Home</div>;
export default Home;
