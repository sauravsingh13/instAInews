import React from "react";
const Footer = () => <footer><p>© 2025 InstAInews</p></footer>;
export default Footer;
