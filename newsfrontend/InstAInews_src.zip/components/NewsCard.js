import React from "react";
import styles from "../styles/NewsCard.module.css";

const NewsCard = ({ item, source }) => (
  <div className={styles.newsCard}>
    <div className={styles.sourceDate}>
      <span className={styles.source}>{source}</span>
      <span className={styles.date}>
        {new Date(item.pubDate || item.isoDate || Date.now()).toDateString()}
      </span>
    </div>
    <h2 className={styles.title}>{item.title}</h2>
    <p className={styles.desc}>{item.contentSnippet || item.description}</p>
    <a href={item.link} target="_blank" rel="noopener noreferrer">
      Read more →
    </a>
  </div>
);

export default NewsCard;
