import { useEffect, useState } from "react";

const useFetchNews = () => {
  const [news, setNews] = useState([]);

  useEffect(() => {
    fetch(`${process.env.REACT_APP_API_URL}/news`)
      .then((res) => res.json())
      .then((data) => setNews(data.feeds || []))
      .catch(console.error);
  }, []);

  return news;
};

export default useFetchNews;
