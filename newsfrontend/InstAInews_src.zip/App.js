import React, { useEffect, useState } from "react";
import styles from "./styles/App.module.css";
import Header from "./components/Header";
import Footer from "./components/Footer";
import ToggleSwitch from "./components/ToggleSwitch";
import NewsCard from "./components/NewsCard";
import useFetchNews from "./hooks/useFetchNews";

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const news = useFetchNews();

  return (
    <div className={darkMode ? styles.appDark : styles.app}>
      <Header />
      <ToggleSwitch darkMode={darkMode} setDarkMode={setDarkMode} />
      <main>
        {news.map((feed, index) => (
          <div key={index}>
            <h3 className={styles.feedTitle}>{feed.source}</h3>
            <div className={styles.grid}>
              {feed.items.map((item, idx) => (
                <NewsCard key={idx} item={item} source={feed.source} />
              ))}
            </div>
          </div>
        ))}
      </main>
      <Footer />
    </div>
  );
}

export default App;
