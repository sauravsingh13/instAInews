import React, { useEffect, useState } from "react";
import "./styles/index.css";
import NewsCard from "./components/NewsCard";

function App() {
  const [news, setNews] = useState([]);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    fetch(`${process.env.REACT_APP_API_URL}/news`)
      .then((res) => res.json())
      .then((data) => {
        console.log(data);
        setNews(data.feeds || []);
      })
      .catch((err) => console.error(err));
  }, []);

  return (
    <div className={darkMode ? "app dark" : "app"}>
      <header>
        <h1>InstAInews</h1>
        <div className="theme-toggle">
          <label className="switch">
            <input
              type="checkbox"
              checked={darkMode}
              onChange={() => setDarkMode((prev) => !prev)}
            />
            <span className="slider round"></span>
          </label>
        </div>
      </header>
      <main>
        {news.map((feed, index) => (
          <div key={index}>
            <h3 className="feed-title">{feed.source}</h3>
            <div className="grid">
              {feed.items.map((item, idx) => (
                <NewsCard key={idx} item={item} source={feed.source} />
              ))}
            </div>
          </div>
        ))}
      </main>
    </div>
  );
}

export default App;
