import React from "react";
import "../styles/index.css";

const NewsCard = ({ item, source }) => (
  <div className="news-card">
    <div className="source-date">
      <span className="source">{source}</span>
      <span className="date">
        {new Date(item.pubDate || item.isoDate || Date.now()).toDateString()}
      </span>
    </div>
    <h2 className="title">{item.title}</h2>
    <p className="desc">{item.contentSnippet || item.description}</p>
    <a href={item.link} target="_blank" rel="noopener noreferrer">
      Read more →
    </a>
  </div>
);

export default NewsCard;
